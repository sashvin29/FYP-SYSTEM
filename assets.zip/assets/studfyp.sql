-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 29, 2021 at 06:54 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studfyp`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `AdminID` tinyint(4) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `coordinator`
--

CREATE TABLE `coordinator` (
  `CoordinatorID` mediumint(9) NOT NULL,
  `LecturerID` mediumint(9) NOT NULL,
  `ActiveStatus` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `file`
--

CREATE TABLE `file` (
  `FileID` mediumint(9) NOT NULL,
  `AdminID` tinyint(4) NOT NULL,
  `FileName` varchar(30) NOT NULL,
  `FileType` varchar(30) NOT NULL,
  `Content` mediumblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `finalyearproject`
--

CREATE TABLE `finalyearproject` (
  `FYPID` mediumint(9) NOT NULL,
  `FYPStudentID` mediumint(9) NOT NULL,
  `FacultySupervisor` mediumint(9) NOT NULL,
  `FacultyEvaluator` mediumint(9) NOT NULL,
  `IndustrialEvaluator` mediumint(9) NOT NULL,
  `ProjectName` varchar(30) DEFAULT NULL,
  `WorkFile` mediumblob DEFAULT NULL,
  `Status` tinyint(1) NOT NULL,
  `Type` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `fypactivity`
--

CREATE TABLE `fypactivity` (
  `ActivityID` smallint(6) NOT NULL,
  `CoordinatorID` mediumint(9) NOT NULL,
  `Title` varchar(20) NOT NULL,
  `StartDateTime` datetime NOT NULL,
  `EndDateTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `fypannouncement`
--

CREATE TABLE `fypannouncement` (
  `AnnouncementID` smallint(6) NOT NULL,
  `CoordinatorID` mediumint(9) NOT NULL,
  `Title` varchar(20) NOT NULL,
  `DateTime` datetime NOT NULL,
  `Content` mediumblob NOT NULL,
  `Status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `fypstudent`
--

CREATE TABLE `fypstudent` (
  `FYPStudentID` mediumint(9) NOT NULL,
  `StudentID` mediumint(9) NOT NULL,
  `ActiveStatus` tinyint(1) NOT NULL,
  `Semester` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `industrialstaff`
--

CREATE TABLE `industrialstaff` (
  `IndustrialStaffID` mediumint(9) NOT NULL,
  `UserID` mediumint(9) NOT NULL,
  `IndustryID` smallint(6) NOT NULL,
  `Designation` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `industry`
--

CREATE TABLE `industry` (
  `IndustryID` smallint(6) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Category` varchar(20) NOT NULL,
  `Address` varchar(40) NOT NULL,
  `ContactNum` varchar(20) NOT NULL,
  `Email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `lecturer`
--

CREATE TABLE `lecturer` (
  `LecturerID` mediumint(9) NOT NULL,
  `UserID` mediumint(9) NOT NULL,
  `StaffID` varchar(20) NOT NULL,
  `OfficeLoc` varchar(20) NOT NULL,
  `Expertise` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `logbook`
--

CREATE TABLE `logbook` (
  `LogbookID` mediumint(9) NOT NULL,
  `FYPStudentID` mediumint(9) NOT NULL,
  `DateTime` datetime NOT NULL,
  `Content` varchar(30) NOT NULL,
  `SupervisorFeedback` varchar(30) DEFAULT NULL,
  `EvaluatorFeedback` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `qrcode`
--

CREATE TABLE `qrcode` (
  `QRCodeID` mediumint(9) NOT NULL,
  `AdminID` tinyint(4) NOT NULL,
  `QRCode` mediumblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE `rating` (
  `RatingID` mediumint(9) NOT NULL,
  `UserID` mediumint(9) NOT NULL,
  `FYPID` mediumint(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `StudentID` mediumint(9) NOT NULL,
  `UserID` mediumint(9) NOT NULL,
  `MatricID` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `submission`
--

CREATE TABLE `submission` (
  `SubmissionID` smallint(6) NOT NULL,
  `FYPStudentID` mediumint(9) NOT NULL,
  `ActivityID` smallint(6) NOT NULL,
  `DateTime` datetime NOT NULL,
  `SubmissionName` varchar(20) NOT NULL,
  `Content` mediumblob NOT NULL,
  `Comment` varchar(40) DEFAULT NULL,
  `Mark` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` mediumint(9) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `PhoneNum` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`AdminID`),
  ADD UNIQUE KEY `Username` (`Username`);

--
-- Indexes for table `coordinator`
--
ALTER TABLE `coordinator`
  ADD PRIMARY KEY (`CoordinatorID`),
  ADD KEY `FK_LecturerID` (`LecturerID`);

--
-- Indexes for table `file`
--
ALTER TABLE `file`
  ADD PRIMARY KEY (`FileID`),
  ADD KEY `FK_AdminID` (`AdminID`);

--
-- Indexes for table `finalyearproject`
--
ALTER TABLE `finalyearproject`
  ADD PRIMARY KEY (`FYPID`),
  ADD KEY `FK_FYPStudentID2` (`FYPStudentID`),
  ADD KEY `FK_FacultySupervisor` (`FacultySupervisor`),
  ADD KEY `FK_FacultyEvaluator` (`FacultyEvaluator`),
  ADD KEY `FK_IndustrialEvaluator` (`IndustrialEvaluator`);

--
-- Indexes for table `fypactivity`
--
ALTER TABLE `fypactivity`
  ADD PRIMARY KEY (`ActivityID`),
  ADD KEY `FK_CoordinatorID` (`CoordinatorID`);

--
-- Indexes for table `fypannouncement`
--
ALTER TABLE `fypannouncement`
  ADD PRIMARY KEY (`AnnouncementID`),
  ADD KEY `FK_CoordinatorID1` (`CoordinatorID`);

--
-- Indexes for table `fypstudent`
--
ALTER TABLE `fypstudent`
  ADD PRIMARY KEY (`FYPStudentID`),
  ADD KEY `FK_StudentID` (`StudentID`);

--
-- Indexes for table `industrialstaff`
--
ALTER TABLE `industrialstaff`
  ADD PRIMARY KEY (`IndustrialStaffID`),
  ADD KEY `FK_IndustryID` (`IndustryID`),
  ADD KEY `FK_UserID2` (`UserID`);

--
-- Indexes for table `industry`
--
ALTER TABLE `industry`
  ADD PRIMARY KEY (`IndustryID`);

--
-- Indexes for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD PRIMARY KEY (`LecturerID`),
  ADD UNIQUE KEY `StaffID` (`StaffID`),
  ADD KEY `FK_UserID1` (`UserID`);

--
-- Indexes for table `logbook`
--
ALTER TABLE `logbook`
  ADD PRIMARY KEY (`LogbookID`),
  ADD KEY `FK_FYPStudentID1` (`FYPStudentID`);

--
-- Indexes for table `qrcode`
--
ALTER TABLE `qrcode`
  ADD PRIMARY KEY (`QRCodeID`),
  ADD KEY `FK_AdminID1` (`AdminID`);

--
-- Indexes for table `rating`
--
ALTER TABLE `rating`
  ADD PRIMARY KEY (`RatingID`),
  ADD KEY `FK_FYPID` (`FYPID`),
  ADD KEY `FK_UserID3` (`UserID`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`StudentID`),
  ADD UNIQUE KEY `MatricID` (`MatricID`),
  ADD KEY `FK_UserID` (`UserID`);

--
-- Indexes for table `submission`
--
ALTER TABLE `submission`
  ADD PRIMARY KEY (`SubmissionID`),
  ADD KEY `FK_FYPStudentID` (`FYPStudentID`),
  ADD KEY `FK_ActivityID` (`ActivityID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD UNIQUE KEY `Username` (`Username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `AdminID` tinyint(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `coordinator`
--
ALTER TABLE `coordinator`
  MODIFY `CoordinatorID` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `file`
--
ALTER TABLE `file`
  MODIFY `FileID` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `finalyearproject`
--
ALTER TABLE `finalyearproject`
  MODIFY `FYPID` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fypactivity`
--
ALTER TABLE `fypactivity`
  MODIFY `ActivityID` smallint(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fypannouncement`
--
ALTER TABLE `fypannouncement`
  MODIFY `AnnouncementID` smallint(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fypstudent`
--
ALTER TABLE `fypstudent`
  MODIFY `FYPStudentID` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `industrialstaff`
--
ALTER TABLE `industrialstaff`
  MODIFY `IndustrialStaffID` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `industry`
--
ALTER TABLE `industry`
  MODIFY `IndustryID` smallint(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lecturer`
--
ALTER TABLE `lecturer`
  MODIFY `LecturerID` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `logbook`
--
ALTER TABLE `logbook`
  MODIFY `LogbookID` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `qrcode`
--
ALTER TABLE `qrcode`
  MODIFY `QRCodeID` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rating`
--
ALTER TABLE `rating`
  MODIFY `RatingID` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `StudentID` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `submission`
--
ALTER TABLE `submission`
  MODIFY `SubmissionID` smallint(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserID` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `coordinator`
--
ALTER TABLE `coordinator`
  ADD CONSTRAINT `FK_LecturerID` FOREIGN KEY (`LecturerID`) REFERENCES `lecturer` (`LecturerID`) ON DELETE CASCADE;

--
-- Constraints for table `file`
--
ALTER TABLE `file`
  ADD CONSTRAINT `FK_AdminID` FOREIGN KEY (`AdminID`) REFERENCES `admin` (`AdminID`) ON DELETE CASCADE;

--
-- Constraints for table `finalyearproject`
--
ALTER TABLE `finalyearproject`
  ADD CONSTRAINT `FK_FYPStudentID2` FOREIGN KEY (`FYPStudentID`) REFERENCES `fypstudent` (`FYPStudentID`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_FacultyEvaluator` FOREIGN KEY (`FacultyEvaluator`) REFERENCES `lecturer` (`LecturerID`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_FacultySupervisor` FOREIGN KEY (`FacultySupervisor`) REFERENCES `lecturer` (`LecturerID`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_IndustrialEvaluator` FOREIGN KEY (`IndustrialEvaluator`) REFERENCES `industrialstaff` (`IndustrialStaffID`) ON DELETE CASCADE;

--
-- Constraints for table `fypactivity`
--
ALTER TABLE `fypactivity`
  ADD CONSTRAINT `FK_CoordinatorID` FOREIGN KEY (`CoordinatorID`) REFERENCES `coordinator` (`CoordinatorID`) ON DELETE CASCADE;

--
-- Constraints for table `fypannouncement`
--
ALTER TABLE `fypannouncement`
  ADD CONSTRAINT `FK_CoordinatorID1` FOREIGN KEY (`CoordinatorID`) REFERENCES `coordinator` (`CoordinatorID`) ON DELETE CASCADE;

--
-- Constraints for table `fypstudent`
--
ALTER TABLE `fypstudent`
  ADD CONSTRAINT `FK_StudentID` FOREIGN KEY (`StudentID`) REFERENCES `student` (`StudentID`) ON DELETE CASCADE;

--
-- Constraints for table `industrialstaff`
--
ALTER TABLE `industrialstaff`
  ADD CONSTRAINT `FK_IndustryID` FOREIGN KEY (`IndustryID`) REFERENCES `industry` (`IndustryID`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_UserID2` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`) ON DELETE CASCADE;

--
-- Constraints for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD CONSTRAINT `FK_UserID1` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`) ON DELETE CASCADE;

--
-- Constraints for table `logbook`
--
ALTER TABLE `logbook`
  ADD CONSTRAINT `FK_FYPStudentID1` FOREIGN KEY (`FYPStudentID`) REFERENCES `fypstudent` (`FYPStudentID`) ON DELETE CASCADE;

--
-- Constraints for table `qrcode`
--
ALTER TABLE `qrcode`
  ADD CONSTRAINT `FK_AdminID1` FOREIGN KEY (`AdminID`) REFERENCES `admin` (`AdminID`) ON DELETE CASCADE;

--
-- Constraints for table `rating`
--
ALTER TABLE `rating`
  ADD CONSTRAINT `FK_FYPID` FOREIGN KEY (`FYPID`) REFERENCES `finalyearproject` (`FYPID`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_UserID3` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`) ON DELETE CASCADE;

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `FK_UserID` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`) ON DELETE CASCADE;

--
-- Constraints for table `submission`
--
ALTER TABLE `submission`
  ADD CONSTRAINT `FK_ActivityID` FOREIGN KEY (`ActivityID`) REFERENCES `fypactivity` (`ActivityID`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_FYPStudentID` FOREIGN KEY (`FYPStudentID`) REFERENCES `fypstudent` (`FYPStudentID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
